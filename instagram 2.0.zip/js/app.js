document.addEventListener("DOMContentLoaded", function () {
    const openModalButton = document.getElementById("openModal");
    const modalOverlay = document.getElementById("modalOverlay");
  
    // Otwieranie modala
    openModalButton.addEventListener("click", function () {
      modalOverlay.classList.add("active");
    });
  
    // Zamknięcie po kliknięciu poza modal
    modalOverlay.addEventListener("click", function (event) {
      if (event.target === modalOverlay) {
        modalOverlay.classList.remove("active");
      }
    });
  });